JavaCars EE422C Programming Assignment #5
The purpose of this lab is to create a Java Applet that races 5 cars
Kevin Yee - kjy252 

Normal Mode (Default): The Normal Mode races 5 cars with randomly generated velocity and acceleration

Skittles Mode (Creativity): The Skittles Mode creates an endlessly looping graphics of sound and graphics implementation.

How to grade: 

Watch the "Normal Mode" to observe the basic function of car racings

Once the finish line has been reached. Click Skittles Mode - followed by Reset.

When in Normal Mode - Reset starts the cars back at the starting line

When in Skittles Mode - Reset makes the endlessly looping graphics go faster! 

Enjoy! 

Applet Runs using: CarDrawer.class
